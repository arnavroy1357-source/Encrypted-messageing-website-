const pages = {
  home: document.getElementById("home"),
  encrypt: document.getElementById("encrypt"),
  decrypt: document.getElementById("decrypt")
};
const warning = document.getElementById("warning");

/* Splash */
window.onload = () => {
  setTimeout(() => {
    document.getElementById("splash").style.display = "none";
  }, 2200);
};

/* Page control */
function showPage(name){
  Object.values(pages).forEach(p => p.classList.remove("active"));
  pages[name].classList.add("active");
  warning.textContent="";
}
function openEncrypt(){ showPage("encrypt"); }
function openDecrypt(){ showPage("decrypt"); }
function goHome(){ showPage("home"); }

/* Emoji detection */
function hasEmoji(text){
  return /[\uD800-\uDBFF][\uDC00-\uDFFF]/.test(text);
}

/* Copy + auto clear */
function copyText(id){
  const el = document.getElementById(id);
  el.select();
  document.execCommand("copy");
  warning.textContent = "📋 Copied! Clipboard clears in 10s";
  setTimeout(()=>{
    document.execCommand("copy");
    warning.textContent = "🧹 Clipboard cleared";
  },10000);
}

/* XOR encryption */
function xorEncrypt(text, password){
  let result="";
  for(let i=0;i<text.length;i++){
    result += String.fromCharCode(
      text.charCodeAt(i) ^ password.charCodeAt(i % password.length)
    );
  }
  return btoa(result);
}
function xorDecrypt(encoded, password){
  const text = atob(encoded);
  let result="";
  for(let i=0;i<text.length;i++){
    result += String.fromCharCode(
      text.charCodeAt(i) ^ password.charCodeAt(i % password.length)
    );
  }
  return result;
}

/* Encrypt */
function encryptMessage(){
  const text = plainText.value;
  const pass = encPassword.value;

  if(!text || !pass){
    warning.textContent="⚠️ Message & password required";
    return;
  }
  if(hasEmoji(text)){
    warning.textContent="⚠️ Emojis not supported";
    return;
  }
  encryptedOutput.value = xorEncrypt(text, pass);
}

/* Decrypt */
function decryptMessage(){
  const enc = encryptedInput.value;
  const pass = decPassword.value;

  if(!enc || !pass){
    warning.textContent="⚠️ Encrypted text & password required";
    return;
  }
  try{
    decryptedOutput.value = xorDecrypt(enc, pass);
  }catch{
    warning.textContent="❌ Wrong password or invalid data";
  }
}

/* Password strength */
encPassword.addEventListener("input", ()=>{
  const val = encPassword.value;
  let s = 0;
  if(val.length >= 6) s += 30;
  if(/[A-Z]/.test(val)) s += 20;
  if(/[0-9]/.test(val)) s += 20;
  if(/[^A-Za-z0-9]/.test(val)) s += 30;

  const bar = document.getElementById("strengthBar");
  bar.style.width = s + "%";
  bar.style.background =
    s < 40 ? "#ef4444" : s < 70 ? "#facc15" : "#22c55e";
});

/* Default */
showPage("home");